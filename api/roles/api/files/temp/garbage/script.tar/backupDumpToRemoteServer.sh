#!/bin/bash

#機能概要
#DBバンプファイルを作成して、その結果を圧縮して、リモート（NAS）サーバーに格納する
#
#前提
#1.本サーバーからリモート（NAS）サーバーがマウント出来ていること
#2.リモートサーバーに$DUMP_COPY_DESTINATION_DIRが存在していること
#
#引数・入力
#なし

export ERR

terminate () {
	echo $ERR
	exit 1
}

create_dump_archive () {
	if [ $1 ]; then 
		local current_dir=$(pwd)
        cd $BASE_DIR
                
		#ダンプデータを準備
		mysqldump -u root --databases thirdparty dsp > $1
		#touch $1 #dummy data
		
		#DBダンプを圧縮
		gzip $1

		cd $current_dir
	fi
}

#TEST=ON

#export USAGE="Usage: $0 REMOTE_SERVER USERNAME"
#if [ $# != 2 ]; then
#	ERR="Wrong execution/usage. $USAGE"
#	terminate
#fi

OTHER_SCRIPT_DIR=.

source $OTHER_SCRIPT_DIR/setBackupVariables.sh

if [ $TEST ]; then
	$OTHER_SCRIPT_DIR/testVariables.sh
fi

#作業用ディレクトリ作成
if [ -d $WORK_DIR ]; then
	rm -r $WORK_DIR
fi
mkdir $WORK_DIR

#作業用ディレクトリに移動
cd $WORK_DIR

#ベースディレクトリ作成
mkdir $CURRENT_DATE
mkdir $BASE_DIR

#MySqlダンプのアーカイブを準備
create_dump_archive $MYSQL_DUMP_FILE

#準備したデータ（$CURRENT_DATEディレクトリ配下）をNASサーバーに移動
if [ -d $DUMP_COPY_DESTINATION_DIR/$CURRENT_DATE ]; then
	mv -f $CURRENT_DATE/* $DUMP_COPY_DESTINATION_DIR/$CURRENT_DATE
else
	mv $CURRENT_DATE $DUMP_COPY_DESTINATION_DIR
fi

#scp -r $CURRENT_DATE $2@$1:$DUMP_COPY_DESTINATION_DIR

#データ移動が成功したら、上記作業ディレクトリを削除
if [ $? == 0 ]; then
	rm -rf $CURRENT_DATE
fi
exit 0

