require "test/unit"

require "csv"

require_relative "../with_different_ofs.rb"

class TestCSV < Test::Unit::TestCase
end
